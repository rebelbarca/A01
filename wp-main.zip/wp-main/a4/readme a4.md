This directory is for a test in week 14

This file is for "non-code" written answers in week 14